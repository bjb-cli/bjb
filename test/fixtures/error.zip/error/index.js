// invalid template config

module.exports = 'error'
